// buttonStyle.js
import styled from 'styled-components/native';
import { Ionicons } from '@expo/vector-icons';
import { Platform } from 'react-native';

export const ContainerButton = styled.View`
width: 40%;
background: rgba(35, 35, 54, 1);
border-radius: 50%;
flex-direction: Column;
padding: 10px;
align-items: center;
gap: 5px;
margin-bottom:30px;
  ${Platform.OS === 'android'
  ? 'elevation: 5;' // Adiciona sombra no Android
  : `
    shadowColor: #000;
    shadowOffset: {
      width: 0,
      height: 2,
    };
    shadowOpacity: 0.2;
    shadowRadius: 4;
  ` // Adiciona sombra no iOS
}
`;

export const TextStyled = styled.Text`
  font-size: 30px;
  color: #fff;
`;

