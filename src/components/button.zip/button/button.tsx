// button.tsx
import React from 'react';
import {ContainerButton, TextStyled} from './buttonStyle'; // Importando o estilo
import { TouchableOpacity } from 'react-native';

const Button: React.FC = () => {
  return (
    <ContainerButton>
      <TouchableOpacity>
        <TextStyled>Logar</TextStyled>
      </TouchableOpacity>
    </ContainerButton>
  );
};

export default Button;
